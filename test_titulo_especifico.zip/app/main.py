# app/main.py - CON SISTEMA DE USUARIOS
from flask import Flask, render_template, request, redirect, flash, session, url_for
import os
from werkzeug.utils import secure_filename
from app.models import init_db, obtener_avisos, obtener_aviso, procesar_pdf_y_guardar
from app.models import obtener_avisos_por_zona, obtener_historico_anual, obtener_estadisticas_historico
from app.models import buscar_avisos, obtener_sugerencias_busqueda
from app.models import obtener_estadisticas_graficos, obtener_top_problemas
from app.models import crear_usuario, verificar_usuario, obtener_usuario_por_id
from app.models import obtener_todos_usuarios, actualizar_rol_usuario, eliminar_usuario
from datetime import datetime
import time

app = Flask(__name__)
app.secret_key = 'clave-secreta-segura-cambiar-en-produccion'  # ¡CAMBIAR EN PRODUCCIÓN!
app.config['UPLOAD_FOLDER'] = 'pdfs'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB límite

# Crear carpetas necesarias
for folder in [app.config['UPLOAD_FOLDER'], 'temp_uploads']:
    if not os.path.exists(folder):
        os.makedirs(folder)

init_db()

# ===== MIDDLEWARE =====
@app.before_request
def before_request():
    # Rutas que no requieren autenticación
    public_routes = ['login', 'static', 'registro']
    
    if request.endpoint not in public_routes and 'user_id' not in session:
        return redirect(url_for('login'))

# ===== FUNCIÓN PARA VERIFICAR ROLES =====
def requiere_rol(rol_requerido):
    """Decorador para verificar roles"""
    def decorator(f):
        from functools import wraps
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            
            user = obtener_usuario_por_id(session['user_id'])
            if not user or user['rol'] != rol_requerido:
                flash('No tienes permisos para acceder a esta página', 'error')
                return redirect(url_for('index'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ===== FILTROS DE TEMPLATE =====
@app.template_filter('format_fecha')
def format_fecha(fecha_string):
    if not fecha_string:
        return ""
    if ' ' in fecha_string:
        return fecha_string.split(' ')[0]
    return fecha_string

# ===== RUTAS DE AUTENTICACIÓN =====
@app.route("/login", methods=["GET", "POST"])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))
    
    if request.method == "POST":
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        user = verificar_usuario(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['rol'] = user['rol']
            session['nombre'] = user['nombre']
            
            flash(f'¡Bienvenido {user["nombre"]}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Usuario o contraseña incorrectos', 'error')
    
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash('Sesión cerrada correctamente', 'info')
    return redirect(url_for('login'))

@app.route("/registro", methods=["GET", "POST"])
def registro():
    if 'user_id' in session:
        return redirect(url_for('index'))
    
    if request.method == "POST":
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        nombre = request.form.get('nombre', '').strip()
        email = request.form.get('email', '').strip()
        
        if len(username) < 3:
            flash('El nombre de usuario debe tener al menos 3 caracteres', 'error')
        elif len(password) < 6:
            flash('La contraseña debe tener al menos 6 caracteres', 'error')
        else:
            if crear_usuario(username, password, 'lector', nombre, email):
                flash('¡Registro exitoso! Ahora puedes iniciar sesión', 'success')
                return redirect(url_for('login'))
            else:
                flash('El nombre de usuario ya existe', 'error')
    
    return render_template("registro.html")

# ===== RUTAS PRINCIPALES =====
@app.route("/")
def index():
    avisos = obtener_avisos()
    user_info = None
    if 'user_id' in session:
        user_info = obtener_usuario_por_id(session['user_id'])
    
    return render_template("index.html", avisos=avisos, user=user_info)

@app.route("/aviso/<int:id>")
def aviso(id):
    aviso = obtener_aviso(id)
    user_info = None
    if 'user_id' in session:
        user_info = obtener_usuario_por_id(session['user_id'])
    
    if aviso:
        return render_template("aviso.html", aviso=aviso, user=user_info)
    else:
        return "Aviso no encontrado", 404

@app.route("/zonas")
def zonas():
    datos_zonas = obtener_avisos_por_zona()
    total_por_zona = {}
    for zona, avisos in datos_zonas.items():
        total_por_zona[zona] = len(avisos)
    
    user_info = None
    if 'user_id' in session:
        user_info = obtener_usuario_por_id(session['user_id'])
    
    return render_template("zonas.html", 
                         zonas=datos_zonas, 
                         totales=total_por_zona,
                         user=user_info)

@app.route("/historico")
def historico():
    year = request.args.get('year', '2025')
    zona = request.args.get('zona', '')
    tipo = request.args.get('tipo', '')
    
    historico_data = obtener_historico_anual(year=year, zona=zona, tipo=tipo)
    estadisticas = obtener_estadisticas_historico(year=year)
    
    user_info = None
    if 'user_id' in session:
        user_info = obtener_usuario_por_id(session['user_id'])
    
    return render_template("historico.html", 
                         avisos_por_zona=historico_data,
                         estadisticas=estadisticas,
                         filtros={'year': year, 'zona': zona, 'tipo': tipo},
                         user=user_info)

@app.route("/buscar")
def buscar():
    from app.models import buscar_avisos, obtener_sugerencias_busqueda
    
    start_time = time.time()
    
    q = request.args.get('q', '')
    zona = request.args.get('zona', '')
    tipo = request.args.get('tipo', '')
    fecha_desde = request.args.get('fecha_desde', '')
    fecha_hasta = request.args.get('fecha_hasta', '')
    pagina = int(request.args.get('pagina', 1))
    
    por_pagina = 20
    offset = (pagina - 1) * por_pagina
    
    resultados_data = None
    total_resultados = 0
    total_paginas = 0
    
    if request.args:
        busqueda_resultados = buscar_avisos(
            q=q, 
            zona=zona, 
            tipo=tipo, 
            fecha_desde=fecha_desde, 
            fecha_hasta=fecha_hasta,
            limit=por_pagina,
            offset=offset
        )
        
        resultados_data = busqueda_resultados['resultados']
        total_resultados = busqueda_resultados['total']
        total_paginas = (total_resultados + por_pagina - 1) // por_pagina
    
    sugerencias = []
    if q and len(q) >= 2:
        sugerencias = obtener_sugerencias_busqueda(q)
    
    tiempo_ejecucion = round(time.time() - start_time, 2)
    
    query_params = request.args.copy()
    if 'pagina' in query_params:
        query_params.pop('pagina')
    query_string = '&'.join([f"{k}={v}" for k, v in query_params.items()])
    
    user_info = None
    if 'user_id' in session:
        user_info = obtener_usuario_por_id(session['user_id'])
    
    return render_template("buscar.html",
                         resultados=resultados_data,
                         total_resultados=total_resultados,
                         total_paginas=total_paginas,
                         pagina=pagina,
                         sugerencias=sugerencias,
                         tiempo_ejecucion=tiempo_ejecucion,
                         query_string=query_string,
                         user=user_info)

@app.route("/graficos")
def graficos():
    year = request.args.get('year', '')
    zona = request.args.get('zona', '')
    
    estadisticas = obtener_estadisticas_graficos(year=year if year else None, 
                                                zona=zona if zona else None)
    
    problemas = obtener_top_problemas(limit=6)
    
    user_info = None
    if 'user_id' in session:
        user_info = obtener_usuario_por_id(session['user_id'])
    
    return render_template("graficos.html",
                         estadisticas=estadisticas,
                         problemas=problemas,
                         filtros={'year': year, 'zona': zona},
                         user=user_info)

# ===== RUTAS DE SUBIDA (SOLO EDITOR Y ADMIN) =====
@app.route("/subir", methods=["GET", "POST"])
@requiere_rol('editor')  # Requiere rol editor o admin
def subir_pdf():
    user_info = obtener_usuario_por_id(session['user_id'])
    
    if request.method == "POST":
        # Verificar si es subida simple o por lotes
        if 'pdf' in request.files:
            # Subida simple (un archivo)
            file = request.files['pdf']
            if file.filename == '':
                flash('No se seleccionó ningún archivo', 'error')
                return redirect(request.url)
            
            if file and file.filename.endswith('.pdf'):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                
                try:
                    resultados = procesar_pdf_y_guardar(filepath, session['user_id'])
                    flash(f'✅ PDF procesado correctamente. Se añadieron {len(resultados)} averías.', 'success')
                except Exception as e:
                    flash(f'❌ Error procesando PDF: {str(e)}', 'error')
                    app.logger.error(f"Error procesando PDF: {e}")
                
                return redirect("/")
        
        elif 'pdfs[]' in request.files:
            # Subida por lotes (múltiples archivos)
            files = request.files.getlist('pdfs[]')
            total_procesados = 0
            total_avisos = 0
            
            for file in files:
                if file.filename == '':
                    continue
                
                if file and file.filename.endswith('.pdf'):
                    filename = secure_filename(file.filename)
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(filepath)
                    
                    try:
                        resultados = procesar_pdf_y_guardar(filepath, session['user_id'])
                        total_procesados += 1
                        total_avisos += len(resultados)
                    except Exception as e:
                        flash(f'❌ Error en {filename}: {str(e)}', 'error')
                        app.logger.error(f"Error procesando {filename}: {e}")
            
            if total_procesados > 0:
                flash(f'✅ {total_procesados} PDFs procesados correctamente. Se añadieron {total_avisos} averías.', 'success')
            
            return redirect("/")
    
    return render_template("subir.html", user=user_info)

# ===== RUTAS DE ADMINISTRACIÓN (SOLO ADMIN) =====
@app.route("/admin/usuarios")
@requiere_rol('admin')
def admin_usuarios():
    usuarios = obtener_todos_usuarios()
    user_info = obtener_usuario_por_id(session['user_id'])
    
    return render_template("admin_usuarios.html", usuarios=usuarios, user=user_info)

@app.route("/admin/cambiar-rol/<int:user_id>", methods=["POST"])
@requiere_rol('admin')
def cambiar_rol(user_id):
    nuevo_rol = request.form.get('rol')
    if nuevo_rol in ['lector', 'editor', 'admin']:
        if actualizar_rol_usuario(user_id, nuevo_rol):
            flash(f'Rol actualizado correctamente', 'success')
        else:
            flash(f'Error al actualizar el rol', 'error')
    
    return redirect(url_for('admin_usuarios'))

@app.route("/admin/eliminar-usuario/<int:user_id>", methods=["POST"])
@requiere_rol('admin')
def eliminar_usuario_route(user_id):
    # No permitir eliminar al propio usuario admin
    if user_id == session['user_id']:
        flash('No puedes eliminarte a ti mismo', 'error')
    else:
        if eliminar_usuario(user_id):
            flash('Usuario eliminado correctamente', 'success')
        else:
            flash('Error al eliminar el usuario', 'error')
    
    return redirect(url_for('admin_usuarios'))

@app.route("/admin/crear-usuario", methods=["POST"])
@requiere_rol('admin')
def crear_usuario_admin():
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')
    rol = request.form.get('rol', 'lector')
    nombre = request.form.get('nombre', '').strip()
    email = request.form.get('email', '').strip()
    
    if len(username) < 3:
        flash('El nombre de usuario debe tener al menos 3 caracteres', 'error')
    elif len(password) < 6:
        flash('La contraseña debe tener al menos 6 caracteres', 'error')
    else:
        if crear_usuario(username, password, rol, nombre, email):
            flash(f'Usuario {username} creado correctamente', 'success')
        else:
            flash('El nombre de usuario ya existe', 'error')
    
    return redirect(url_for('admin_usuarios'))

# ===== PÁGINA DE PERFIL =====
@app.route("/perfil")
def perfil():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_info = obtener_usuario_por_id(session['user_id'])
    return render_template("perfil.html", user=user_info)

@app.route("/cambiar-password", methods=["POST"])
def cambiar_password():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    password_actual = request.form.get('password_actual', '')
    nueva_password = request.form.get('nueva_password', '')
    confirmar_password = request.form.get('confirmar_password', '')
    
    user = verificar_usuario(session['username'], password_actual)
    if not user:
        flash('Contraseña actual incorrecta', 'error')
    elif len(nueva_password) < 6:
        flash('La nueva contraseña debe tener al menos 6 caracteres', 'error')
    elif nueva_password != confirmar_password:
        flash('Las contraseñas nuevas no coinciden', 'error')
    else:
        # Actualizar contraseña
        import hashlib
        nueva_password_hash = hashlib.sha256(nueva_password.encode()).hexdigest()
        
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE usuarios SET password_hash = ? WHERE id = ?", 
                 (nueva_password_hash, session['user_id']))
        conn.commit()
        conn.close()
        
        flash('Contraseña actualizada correctamente', 'success')
    
    return redirect(url_for('perfil'))

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)